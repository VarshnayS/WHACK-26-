/**
 * src/audit/heatmapMaterial.ts: collision heatmap grid material (Tier 1)
 * Owner: AUDIT agent. Edits only in src/audit/.
 *
 * Same grid-line maths as debugMaterial / agentMaterial, with NO sonar mask: the whole grid is
 * visible. Grid lines are white-ish by default and turn yellow -> red near collision hotspots.
 *
 * One set of shared uniforms (heatmapUniforms) feeds every material made here, so
 * setHeatmapHotspots() updates tiles and agents at once.
 *
 * Two variants, picked per mesh by the report:
 *   - world-space grid (tiles; tiles never move)
 *   - object-space grid (agents; lines travel with the limbs, InstancedMesh aware), same as agentMaterial.ts
 */
import * as THREE from 'three';
import { GRID_SIZE } from '../../config';

/** Size of the hotspot arrays in the shader. */
export const MAX_HOTSPOTS = 50;

/** Influence radius of a hotspot, in metres (cells are 2 m wide, so this blends neighbours). */
export const HEATMAP_RADIUS = 4;

export interface HeatmapHotspot {
  /** Local metres. */
  x: number;
  z: number;
  /** 0..1: 0 = barely any collisions (yellow), 1 = the most (red). */
  intensity: number;
}

export const heatmapUniforms = {
  uHotspots: { value: Array.from({ length: MAX_HOTSPOTS }, () => new THREE.Vector3()) },
  uIntensities: { value: new Array<number>(MAX_HOTSPOTS).fill(0) },
  uHotspotCount: { value: 0 },
  uHotspotRadius: { value: HEATMAP_RADIUS },
  /** Brightness of grid lines where there are no collisions. */
  uBaseBrightness: { value: 0.45 },
};

/** Load up to MAX_HOTSPOTS hotspots (extra ones are ignored). x/z go in vec3.x / vec3.z. */
export function setHeatmapHotspots(hotspots: HeatmapHotspot[]): void {
  const n = Math.min(hotspots.length, MAX_HOTSPOTS);
  for (let i = 0; i < MAX_HOTSPOTS; i++) {
    if (i < n) {
      heatmapUniforms.uHotspots.value[i].set(hotspots[i].x, 0, hotspots[i].z);
      heatmapUniforms.uIntensities.value[i] = hotspots[i].intensity;
    } else {
      heatmapUniforms.uHotspots.value[i].set(0, 0, 0);
      heatmapUniforms.uIntensities.value[i] = 0;
    }
  }
  heatmapUniforms.uHotspotCount.value = n;
}

const vertexShader = /* glsl */ `
  varying vec3 vWorldPos;
  varying vec3 vGridPos;
  void main() {
    mat4 model = modelMatrix;
    #ifdef USE_INSTANCING
      model = modelMatrix * instanceMatrix;
    #endif
    vec4 wp = model * vec4(position, 1.0);
    vWorldPos = wp.xyz;
    #ifdef OBJECT_GRID
      // object-space position scaled by the part's own scale (same as agentMaterial.ts)
      vec3 s = vec3(length(model[0].xyz), length(model[1].xyz), length(model[2].xyz));
      vGridPos = position * s;
    #else
      vGridPos = wp.xyz;
    #endif
    gl_Position = projectionMatrix * viewMatrix * wp;
  }
`;

const fragmentShader = /* glsl */ `
  uniform float uGridSize;
  uniform vec3 uHotspots[MAX_HOTSPOTS];
  uniform float uIntensities[MAX_HOTSPOTS];
  uniform float uHotspotCount;
  uniform float uHotspotRadius;
  uniform float uBaseBrightness;
  varying vec3 vWorldPos;
  varying vec3 vGridPos;

  void main() {
    // grid lines (same formula as the game's debug / agent materials)
    vec3 p = vGridPos / uGridSize;
    vec3 fw = max(fwidth(p), vec3(1e-4));
    vec3 g = abs(fract(p - 0.5) - 0.5) / fw;
    float grid = 1.0 - min(min(min(g.x, g.y), g.z), 1.0);
    // lines closer together than a few pixels become a smear: fade them out
    grid *= 1.0 - smoothstep(0.3, 0.7, max(max(fw.x, fw.y), fw.z));

    // heat: sum of each hotspot's intensity, fading out with horizontal distance
    float heat = 0.0;
    for (int i = 0; i < MAX_HOTSPOTS; i++) {
      if (float(i) >= uHotspotCount) break;
      float d = distance(vWorldPos.xz, uHotspots[i].xz);
      float falloff = 1.0 - smoothstep(0.0, uHotspotRadius, d);
      heat += falloff * uIntensities[i];
    }
    heat = clamp(heat, 0.0, 1.0);
    // how strongly the heat colour replaces the base colour (a lone collision is already clearly visible)
    float presence = clamp(heat * 3.0, 0.0, 1.0);

    vec3 yellow = vec3(1.0, 0.9, 0.1);
    vec3 red = vec3(1.0, 0.1, 0.05);
    vec3 baseCol = vec3(uBaseBrightness);
    vec3 col = mix(baseCol, mix(yellow, red, heat), presence);

    gl_FragColor = vec4(col * grid, 1.0);
  }
`;

/**
 * Heatmap grid material. `gridSize` is the line spacing in metres. `objectSpace` true = grid
 * attached to the object (agents), false = grid fixed in the world (tiles).
 */
export function createHeatmapMaterial(
  name: string,
  opts: { gridSize?: number; objectSpace?: boolean } = {},
): THREE.ShaderMaterial {
  const material = new THREE.ShaderMaterial({
    name,
    side: THREE.DoubleSide,
    uniforms: { ...heatmapUniforms, uGridSize: { value: opts.gridSize ?? GRID_SIZE } },
    defines: opts.objectSpace ? { MAX_HOTSPOTS, OBJECT_GRID: 1 } : { MAX_HOTSPOTS },
    vertexShader,
    fragmentShader,
  });
  material.userData.auditHeatmap = true;
  return material;
}