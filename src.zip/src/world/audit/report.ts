/**
 * src/audit/report.ts: 3D collision heatmap report (Tier 1)
 * Owner: AUDIT agent. Edits only in src/audit/.
 *
 * Press V: the game camera rises above the player and looks straight down, tiles and agents switch
 * to the heatmap grid material (yellow = few collisions, red = many), and an HTML overlay shows the
 * top-5 list, Export JSON, Clear data and attributions. Press V again to restore everything.
 * Press J (dev) to inject 20 fake events.
 * Started by initAudit() in ./log.ts.
 */
import * as THREE from 'three';
import { CORRIDOR_BEARING, CORRIDOR_HALF_WIDTH, CORRIDOR_LENGTH } from '../../config';
import type { World } from '../index';
import { createHeatmapMaterial, MAX_HOTSPOTS, setHeatmapHotspots } from './heatmapMaterial';
import {
  clearEvents,
  getAllEvents,
  localToLatLon,
  type AuditApi,
  type AuditEvent,
  type AuditableWorld,
} from './log';

// ---------------------------------------------------------------------------
// Aggregation
// ---------------------------------------------------------------------------

/** Hotspot cell size in metres. */
const CELL_SIZE = 2;
const BUILT_HITS = new Set(['building', 'low_obstacle', 'street_furniture']);
/**
 * Intensity = cell count / max(highest cell count, HEAT_FULL_SCALE). So a lone collision stays
 * yellow-ish unless the run history really has many collisions in one place.
 */
const HEAT_FULL_SCALE = 5;

interface Cell {
  x: number; // cell centre, local metres
  z: number;
  built: number;
  agent: number;
  total: number;
  types: Map<string, number>;
}

interface Aggregate {
  cells: Cell[];
  /** Top 5, shown in the panel. */
  top: Cell[];
  /** Top MAX_HOTSPOTS, sent to the shader. */
  hot: Cell[];
  maxCount: number;
  eventCount: number;
  runCount: number;
}

function aggregate(events: AuditEvent[]): Aggregate {
  const cells = new Map<string, Cell>();
  const runs = new Set<string>();
  let eventCount = 0;

  for (const e of events) {
    if (!e || !e.position || !Number.isFinite(e.position.x) || !Number.isFinite(e.position.z)) continue;
    eventCount++;
    runs.add(e.runId);

    const ix = Math.floor(e.position.x / CELL_SIZE);
    const iz = Math.floor(e.position.z / CELL_SIZE);
    const key = `${ix},${iz}`;
    let cell = cells.get(key);
    if (!cell) {
      cell = { x: (ix + 0.5) * CELL_SIZE, z: (iz + 0.5) * CELL_SIZE, built: 0, agent: 0, total: 0, types: new Map() };
      cells.set(key, cell);
    }
    if (BUILT_HITS.has(e.hit)) cell.built++;
    else cell.agent++;
    cell.total++;
    cell.types.set(e.hit, (cell.types.get(e.hit) ?? 0) + 1);
  }

  const list = [...cells.values()];
  const sorted = list.slice().sort((a, b) => b.total - a.total);
  return {
    cells: list,
    top: sorted.slice(0, 5),
    hot: sorted.slice(0, MAX_HOTSPOTS),
    maxCount: sorted.length ? sorted[0].total : 0,
    eventCount,
    runCount: runs.size,
  };
}

// ---------------------------------------------------------------------------
// UI helpers
// ---------------------------------------------------------------------------

const FONT = '12px ui-monospace, SFMono-Regular, Menlo, Consolas, monospace';

function el<K extends keyof HTMLElementTagNameMap>(
  tag: K,
  style: Partial<CSSStyleDeclaration> = {},
  text?: string,
): HTMLElementTagNameMap[K] {
  const node = document.createElement(tag);
  Object.assign(node.style, style);
  if (text !== undefined) node.textContent = text;
  return node;
}

function styleButton(b: HTMLButtonElement): HTMLButtonElement {
  Object.assign(b.style, {
    font: FONT,
    color: '#fff',
    background: '#000',
    border: '1px solid #fff',
    padding: '6px 12px',
    cursor: 'pointer',
    marginLeft: '8px',
  } as Partial<CSSStyleDeclaration>);
  return b;
}

/** Walk every mesh under a root. */
function eachMesh(root: THREE.Object3D, fn: (mesh: THREE.Mesh) => void): void {
  root.traverse((obj) => {
    const mesh = obj as THREE.Mesh;
    if (mesh.isMesh) fn(mesh);
  });
}

// ---------------------------------------------------------------------------
// Report
// ---------------------------------------------------------------------------

/** Build the report and key handlers. Returns a dispose function. */
export function initReport(world: World): () => void {
  const w = world as AuditableWorld;
  const camera = world.camera;
  let open = false;
  let token = 0;
  let sweepTimer: number | undefined;

  // --- overlay DOM (no canvas: the 3D world is the picture) ---
  const root = el('div', {
    position: 'fixed',
    inset: '0',
    color: '#fff',
    font: FONT,
    zIndex: '1000',
    display: 'none',
    pointerEvents: 'none', // let the page through; only the panel / buttons catch clicks
  });
  const panel = el('div', {
    position: 'absolute',
    top: '12px',
    left: '12px',
    maxWidth: '420px',
    padding: '10px 12px',
    border: '1px solid #fff',
    background: 'rgba(0,0,0,0.85)',
    lineHeight: '1.5',
    pointerEvents: 'auto',
  });
  const buttons = el('div', { position: 'absolute', top: '12px', right: '12px', pointerEvents: 'auto' });
  const exportBtn = styleButton(el('button', {}, 'Export JSON'));
  const clearBtn = styleButton(el('button', {}, 'Clear data'));
  buttons.append(exportBtn, clearBtn);
  const footer = el('div', {
    position: 'absolute',
    left: '12px',
    bottom: '10px',
    right: '12px',
    fontSize: '11px',
    opacity: '0.9',
    textShadow: '0 0 4px #000, 0 0 4px #000',
  });
  root.append(panel, buttons, footer);
  document.body.appendChild(root);

  // --- camera: move the game camera (so 3D-tile LOD streaming keeps following it) ---
  const bearing = (CORRIDOR_BEARING * Math.PI) / 180;
  // Local frame: +X west, +Z north. u = along the road (screen up), as in the previous report.
  const ux = -Math.sin(bearing);
  const uz = Math.cos(bearing);

  interface SavedCamera {
    position: THREE.Vector3;
    quaternion: THREE.Quaternion;
    up: THREE.Vector3;
    far: number;
  }
  let savedCamera: SavedCamera | null = null;
  const focus = new THREE.Vector3(); // player position when the report opened
  let height = 120;

  function fitHeight(): number {
    const persp = camera as THREE.PerspectiveCamera;
    if (!persp.isPerspectiveCamera) return 120;
    const tanHalf = Math.tan((persp.fov * Math.PI) / 360);
    const halfAcross = CORRIDOR_HALF_WIDTH + 8;
    const halfAlong = CORRIDOR_LENGTH / 2 + 8;
    return Math.max(halfAlong / tanHalf, halfAcross / (tanHalf * Math.max(persp.aspect, 0.1)));
  }

  function applyTopDownPose(): void {
    camera.up.set(ux, 0, uz);
    camera.position.set(focus.x, height, focus.z);
    camera.lookAt(focus.x, 0, focus.z);
    camera.updateMatrixWorld(true);
  }

  function enterTopDown(): void {
    savedCamera = {
      position: camera.position.clone(),
      quaternion: camera.quaternion.clone(),
      up: camera.up.clone(),
      far: (camera as THREE.PerspectiveCamera).far,
    };
    focus.copy(camera.position);
    height = fitHeight();
    const cam = camera as THREE.PerspectiveCamera;
    if (cam.isPerspectiveCamera && cam.far < height + 50) {
      cam.far = height + 50;
      cam.updateProjectionMatrix();
    }
    applyTopDownPose();
  }

  function leaveTopDown(): void {
    if (!savedCamera) return;
    camera.position.copy(savedCamera.position);
    camera.quaternion.copy(savedCamera.quaternion);
    camera.up.copy(savedCamera.up);
    const cam = camera as THREE.PerspectiveCamera;
    if (cam.isPerspectiveCamera && cam.far !== savedCamera.far) {
      cam.far = savedCamera.far;
      cam.updateProjectionMatrix();
    }
    camera.updateMatrixWorld(true);
    savedCamera = null;
  }

  // Re-apply the pose every frame in case the controller writes the camera. Assumes
  // world.onUpdate(fn) exists and calls fn every frame (not verified; see notes).
  const onUpdate = (w as unknown as { onUpdate?: (fn: (dt: number) => void) => unknown }).onUpdate;
  if (typeof onUpdate === 'function') {
    onUpdate.call(world, () => {
      if (open) applyTopDownPose();
    });
  } else {
    console.warn('[audit] world.onUpdate not available; the camera pose is only set once when V is pressed.');
  }

  // --- material swapping ---
  /** Original material of each swapped mesh. */
  const saved = new Map<THREE.Mesh, THREE.Material | THREE.Material[]>();
  /** Heatmap materials by variant + grid size (agents keep their own line spacing). */
  const heatMaterials = new Map<string, THREE.ShaderMaterial>();

  function heatMaterialFor(original: THREE.Material | THREE.Material[], objectSpace: boolean): THREE.ShaderMaterial {
    const first = Array.isArray(original) ? original[0] : original;
    let gridSize: number | undefined;
    if (objectSpace) {
      const v = (first as THREE.ShaderMaterial | undefined)?.uniforms?.uGridSize?.value;
      if (typeof v === 'number') gridSize = v;
    }
    const key = `${objectSpace ? 'obj' : 'world'}:${gridSize ?? 'default'}`;
    let m = heatMaterials.get(key);
    if (!m) {
      m = createHeatmapMaterial(`auditHeatmap-${key}`, { gridSize, objectSpace });
      heatMaterials.set(key, m);
    }
    return m;
  }

  function swapTree(rootObj: THREE.Object3D | undefined, objectSpace: boolean): void {
    if (!rootObj) return;
    eachMesh(rootObj, (mesh) => {
      const cur = mesh.material;
      const first = Array.isArray(cur) ? cur[0] : cur;
      if (first?.userData?.auditHeatmap) return; // already ours
      // New mesh (tile streamed in) or a mesh whose material was reassigned (e.g. R key): remember it.
      saved.set(mesh, cur);
      mesh.material = heatMaterialFor(cur, objectSpace);
    });
  }

  /** Swap everything now; also catches tiles that stream in while the report is open. */
  function sweep(): void {
    for (const mesh of saved.keys()) if (!mesh.parent) saved.delete(mesh); // removed from the scene
    swapTree(world.tilesGroup, false);
    swapTree(world.agentsGroup, true);
  }

  function restoreMaterials(): void {
    for (const [mesh, material] of saved) mesh.material = material;
    saved.clear();
  }

  // --- panel / footer ---
  function renderPanel(data: Aggregate): void {
    panel.replaceChildren();
    panel.append(el('div', { fontWeight: 'bold' }, 'AUDIT: collision heatmap'));
    panel.append(
      el('div', {}, `${data.eventCount} events, ${data.runCount} run${data.runCount === 1 ? '' : 's'}, ${CELL_SIZE} m cells`),
    );
    const bar = el('div', {
      marginTop: '6px',
      height: '8px',
      background: 'linear-gradient(to right, #ffe61a, #ff1a0d)',
    });
    panel.append(bar);
    const labels = el('div', { display: 'flex', justifyContent: 'space-between', opacity: '0.8' });
    labels.append(el('span', {}, 'few'), el('span', {}, 'many'));
    panel.append(labels);

    panel.append(el('div', { marginTop: '8px', fontWeight: 'bold' }, 'Top 5 hotspots'));
    if (data.top.length === 0) {
      panel.append(el('div', { opacity: '0.7' }, 'No events yet. (J injects 20 test events)'));
    }
    data.top.forEach((cell, i) => {
      const { lat, lon } = localToLatLon(cell.x, cell.z);
      const types = [...cell.types.entries()]
        .sort((a, b) => b[1] - a[1])
        .map(([type, n]) => `${type}×${n}`)
        .join(', ');
      const row = el('div', { marginTop: '4px' });
      row.append(
        el('div', {}, `#${i + 1}  count ${cell.total}  (x ${cell.x.toFixed(0)}, z ${cell.z.toFixed(0)})`),
        el('div', { opacity: '0.8' }, `${lat.toFixed(5)}, ${lon.toFixed(5)}`),
        el('div', { opacity: '0.8' }, types),
      );
      panel.append(row);
    });
    panel.append(el('div', { marginTop: '8px', opacity: '0.6' }, 'V close · J dev: inject 20 fake events'));
  }

  function renderFooter(): void {
    const parts = ['Google Maps', ...(w.attributions ?? []), '© OpenStreetMap contributors'];
    footer.textContent = parts.join(' · ');
  }

  async function refresh(): Promise<void> {
    const mine = ++token;
    const events = await getAllEvents();
    if (mine !== token || !open) return;
    const data = aggregate(events);
    const denom = Math.max(data.maxCount, HEAT_FULL_SCALE);
    setHeatmapHotspots(data.hot.map((c) => ({ x: c.x, z: c.z, intensity: c.total / denom })));
    renderPanel(data);
    renderFooter();
  }

  function setOpen(value: boolean): void {
    if (value === open) return;
    open = value;
    root.style.display = open ? 'block' : 'none';
    if (open) {
      document.exitPointerLock?.(); // free the mouse for the buttons (the controller ignores input while unlocked)
      enterTopDown();
      sweep();
      sweepTimer = window.setInterval(sweep, 300);
      void refresh();
    } else {
      token++; // cancel any in-flight refresh
      if (sweepTimer !== undefined) window.clearInterval(sweepTimer);
      sweepTimer = undefined;
      restoreMaterials();
      leaveTopDown();
    }
  }

  // --- buttons ---
  exportBtn.addEventListener('click', async () => {
    const events = await getAllEvents();
    const json = JSON.stringify({ exportedAt: new Date().toISOString(), events }, null, 2);
    const url = URL.createObjectURL(new Blob([json], { type: 'application/json' }));
    const a = el('a');
    a.href = url;
    a.download = `blind-simulator-audit-${new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-')}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  });

  clearBtn.addEventListener('click', async () => {
    if (!window.confirm('Delete all stored audit runs? This cannot be undone.')) return;
    await clearEvents();
    void refresh();
  });

  // --- dev test: J injects 20 fake events around the player ---
  function injectFakeEvents(): void {
    const audit: AuditApi | undefined = w.audit;
    if (!audit) {
      console.warn('[audit] world.audit is not installed; call initAudit(world) first.');
      return;
    }
    // While the report is open the camera is overhead, so use the stored player position.
    const origin = open ? focus : world.camera.position;
    const rand = (a: number, b: number) => a + Math.random() * (b - a);

    // A few hotspot centres within ~12 m so clustering is visible.
    const centres = Array.from({ length: 5 }, () => ({ x: origin.x + rand(-12, 12), z: origin.z + rand(-12, 12) }));
    const hits: Array<[string, number]> = [
      ['building', 0.35],
      ['low_obstacle', 0.2],
      ['street_furniture', 0.15],
      ['pedestrian', 0.15],
      ['car', 0.05],
      ['entity', 0.1],
    ];
    const pickHit = (): string => {
      let r = Math.random();
      for (const [name, p] of hits) {
        if ((r -= p) <= 0) return name;
      }
      return 'building';
    };
    const eventY = savedCamera ? savedCamera.position.y : origin.y;

    for (let i = 0; i < 20; i++) {
      const c = centres[Math.floor(Math.random() * centres.length)];
      const position = { x: c.x + rand(-0.9, 0.9), y: eventY, z: c.z + rand(-0.9, 0.9) };
      const angle = rand(0, Math.PI * 2);
      const normal = { x: Math.cos(angle), y: 0, z: Math.sin(angle) };
      const impactSpeed = rand(0.5, 5.5);

      if (i < 4) {
        // No `hit`: exercises the height-based classification (two low, two high).
        audit.log({ position, point: { ...position, y: i % 2 === 0 ? 0.3 : 1.3 }, normal, impactSpeed, synthetic: true });
        continue;
      }
      const hit = pickHit();
      audit.log({
        kind: hit === 'entity' ? 'caught' : 'collision',
        hit,
        position,
        normal,
        impactSpeed,
        caneActive: Math.random() < 0.5,
        synthetic: true,
      });
    }
    console.info('[audit] injected 20 synthetic events (J)');
    if (open) void refresh();
  }

  // --- keys ---
  const onKeyDown = (e: KeyboardEvent): void => {
    const target = e.target as HTMLElement | null;
    if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable)) return;
    if (e.repeat || e.ctrlKey || e.metaKey || e.altKey) return;
    if (e.code === 'KeyV') setOpen(!open);
    else if (e.code === 'KeyJ') injectFakeEvents();
  };
  const onResize = (): void => {
    if (!open) return;
    height = fitHeight();
    applyTopDownPose();
  };
  window.addEventListener('keydown', onKeyDown);
  window.addEventListener('resize', onResize);

  return () => {
    setOpen(false);
    window.removeEventListener('keydown', onKeyDown);
    window.removeEventListener('resize', onResize);
    for (const m of heatMaterials.values()) m.dispose();
    heatMaterials.clear();
    root.remove();
  };
}